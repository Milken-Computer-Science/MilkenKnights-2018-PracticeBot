#pragma once

namespace ctre {
namespace phoenix {
namespace motorcontrol {

enum class SensorTerm {
	SensorTerm_Sum0,
	SensorTerm_Sum1,
	SensorTerm_Diff0,
	SensorTerm_Diff1,
};

}
}
}
